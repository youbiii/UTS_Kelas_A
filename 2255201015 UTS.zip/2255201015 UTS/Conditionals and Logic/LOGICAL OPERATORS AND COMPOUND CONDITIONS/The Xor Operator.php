<?php
$fruit = "banana";
$protein = "pork";
  //   Nama:Catur nurul huda
//   NIm: 2255201015
// Write your code below:
if ($fruit == "banana" xor $protein == "chicken"){
  echo "Dig in!";
}