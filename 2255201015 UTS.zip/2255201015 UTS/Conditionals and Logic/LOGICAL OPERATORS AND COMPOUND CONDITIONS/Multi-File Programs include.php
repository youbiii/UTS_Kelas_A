<?php
include "top_bread.php";
include "mayo.php";
include "lettuce.php";

echo "Sliced, ripe potetoes\nBacon\nTurkey\n";

include "bottom_bread.php";
//   Nama:Catur nurul huda
//   NIm: 2255201015