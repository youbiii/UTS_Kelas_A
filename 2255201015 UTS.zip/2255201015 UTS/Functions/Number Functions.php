<?php
// Write your code below:
function calculateDistance($first, $second)
{
  return abs($first - $second);
}

function calculateTip($total)
{
  return round($total * 1.18);
}
//   Nama:Catur nurul huda
//   NIm: 2255201015
