<?php
$a = 29;
$b = "You did it!";
$c = STR_PAD_BOTH;
$d = "*~*";

// Write your code below:
echo str_pad($b, $a, $d, $c);
//   Nama:Catur nurul huda
//   NIm: 2255201015
