<?php
$first = "Welcome to the magical world of built-in fuctions.";
  
$second = 82137012983; 

//Write your code below:
echo gettype($first);

echo gettype($second);

var_dump($first);

var_dump($second);
//   Nama:Catur nurul huda
//   NIm: 2255201015