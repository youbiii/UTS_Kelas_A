<?php
// Write your code below:
function convertToShout($str)
{
  return strtoupper($str) . "!";
}

function tipGenerously($cost)
{
  return ceil($cost * 1.2);
} 

function calculateCircleArea($diameter)
{
  return pi() * ($diameter/2)**2;
}
//   Nama:Catur nurul huda
//   NIm: 2255201015