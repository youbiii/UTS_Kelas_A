<?php
//   Nama:Catur nurul huda
//   NIm: 2255201015
echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 52);