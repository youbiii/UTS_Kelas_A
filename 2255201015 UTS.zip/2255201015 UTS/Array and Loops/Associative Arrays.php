<?php
// Write your code below:
$php_array = array(
    "language" => "PHP", 
    "creator" => "Rasmus Lerdorf", 
    "year_created" => 1995, 
    "filename_extensions" => [".php", ".phtml", ".php3", ".php4", ".php5", ".php7", ".phps", ".php-s", ".pht", ".phar"]
  );
  
  $php_short = [
    "language" => "PHP", 
    "creator" => "Rasmus Lerdorf", 
    "year_created" => 1995, 
    "filename_extensions" => [".php", ".phtml", ".php3", ".php4", ".php5", ".php7", ".phps", ".php-s", ".pht", ".phar"]
  ];