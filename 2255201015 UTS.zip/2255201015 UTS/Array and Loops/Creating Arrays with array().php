<?php
// Write your code below:
$first_array = array("hello", 88, "my", -12361.11, "friend");

echo count($first_array);

//   Nama:Catur nurul huda
//   NIm: 2255201015