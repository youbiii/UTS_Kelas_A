<?php

$change_me = [3, 6, 9];
// Write your code below:
$change_me[] = "wohoo";

$change_me[] = 87;

$change_me[1] = "tadpole";

print_r($change_me);