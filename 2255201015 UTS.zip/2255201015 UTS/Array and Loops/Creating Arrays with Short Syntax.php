<?php

//   Nama:Catur nurul huda
//   NIm: 2255201015
// Write your code below:
$with_function = array("PHP" , "popcorn" , 555.55);
$with_short = ["PHP" , "popcorn" , 555.55];
