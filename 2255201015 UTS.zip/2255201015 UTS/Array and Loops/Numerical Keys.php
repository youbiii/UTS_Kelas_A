<?php
// Write your code below:
$hybrid_array = ["cat", "dog", 9, 15.3];

$hybrid_array[8] = "five more";

print_r($hybrid_array);

array_push($hybrid_array, rand());

//   Nama:Catur nurul huda
//   NIm: 2255201015
echo $hybrid_array[9];