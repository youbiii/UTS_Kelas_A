<?php
$message = ["hy bro", " You're doing great", " Keep up the good work!\n"];

$favorite_nums = [7, 201, 33, 88, 91];
// Write your code below:
echo implode("!", $message);

print_r($favorite_nums);
//   Nama:Catur nurul huda
//   NIm: 2255201015