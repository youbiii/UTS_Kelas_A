<?php
$count = 1;
//   Nama:Catur nurul huda
//   NIm: 2255201015
while($count <= 100)
{
   if($count % 33 == 0 ) {
    echo  " is divisible by 33\n ";
   }
  $count += 1 ;
}