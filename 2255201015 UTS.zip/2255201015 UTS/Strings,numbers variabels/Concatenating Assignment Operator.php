<?php
 echo "I'm going on a picnic!";

 $sentence = "\nI'm going on a picnic, and I'm taking apples";

 echo $sentence;

//   Nama:Catur nurul huda
//   NIm: 2255201015


// Write your code below:

 $sentence .= ", bananas";
 
  echo $sentence;
  
  $sentence .= ", grapes";

  echo $sentence;
