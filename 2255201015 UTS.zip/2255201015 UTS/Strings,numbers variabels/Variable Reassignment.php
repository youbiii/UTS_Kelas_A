<?php

//   Nama:Catur nurul huda
//   NIm: 2255201015

$movie = "___";
// Add your code here:
$movie = "horor";
$old_favorite = $movie;

echo "I'm a fickle person, my favorite movie used to be $movie.";

// Add a statement here:
$movie = "actio";

echo "\nBut now my favorite is $movie.";

// Add a statement below:
echo "\nfilm is fun but $old_favorite";
