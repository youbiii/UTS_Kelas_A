<?php
//   Nama:Catur nurul huda
//   NIm: 2255201015

// Write your code below:
$my_num = 12;

	$answer = $my_num;

	$answer += 2;

	$answer *= 2;

	$answer -= 2;

	$answer /= 2;

	$answer -= $my_num;

	echo $answer;
