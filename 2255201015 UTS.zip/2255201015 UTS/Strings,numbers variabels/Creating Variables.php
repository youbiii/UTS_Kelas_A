<?php
// Write your code below:
$silly = "without common sense, absurd, ridiculous";
$biography = "\nhallo";
$favorite_food  = "\n" . "tur" . "duck" . "en";
  
//   Nama:Catur nurul huda
//   NIm: 2255201015


