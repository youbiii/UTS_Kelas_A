<?php
// Write your code below:
  echo "Hello, world!.";

//   Nama:Catur nurul huda
//   NIm: 2255201015