<?php
// Write your code below:
$name = "catur nurul huda";
$language ="Indonesia";
echo $name;
echo "\n" . $language;

//   Nama:Catur nurul huda
//   NIm: 2255201015
