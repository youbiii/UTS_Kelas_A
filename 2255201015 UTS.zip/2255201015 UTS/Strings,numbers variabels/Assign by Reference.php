<?php
/* Imagine a lot of code here */  
$very_bad_unclear_name = "20 chicken wings";

// Write your code here:
  $order =& $very_bad_unclear_name; 

  $order .= ", 2 cheeseburger";

  $order .= ", 3 side salads";

    
  // Don't change the line below
  echo "\nYour order is: $very_bad_unclear_name.";
//   Nama:Catur nurul huda
//   NIm: 2255201015
