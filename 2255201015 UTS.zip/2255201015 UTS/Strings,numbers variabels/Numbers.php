<?php
// Write your code below:
$age = 11;
echo $age;
echo"\n";
$movie_rating = 3.2;
echo $movie_rating;
  
//   Nama:Catur nurul huda
//   NIm: 2255201015