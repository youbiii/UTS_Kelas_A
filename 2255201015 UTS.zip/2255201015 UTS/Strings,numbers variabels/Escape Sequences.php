<?php
// Write your code below:
 echo "1. learn php";
 echo "\n2. Eat breakfast";
 echo "\n3. Play a game ";
 
 //   Nama:Catur nurul huda
//   NIm: 2255201015