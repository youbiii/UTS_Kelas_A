<?php
//   Nama:Catur nurul huda
//   NIm: 2255201015
// Write your code below:
  
echo 7 + 5;